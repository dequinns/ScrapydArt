==========
ScrapydArt
==========

.. image:: https://secure.travis-ci.org/scrapy/scrapyd.svg?branch=master
    :target: http://travis-ci.org/scrapy/scrapyd

.. image:: https://codecov.io/gh/scrapy/scrapyd/branch/master/graph/badge.svg
    :target: https://codecov.io/gh/scrapy/scrapyd

ScrapydArt base on Scrapyd, and added auth/filter/order…… and added new API

ScrapydArt在Scrapyd基础上新增了权限验证、筛选过滤、排序、数据统计以及排行榜等功能，并且有了更强大的API。

ScrapydArt is a service for running `Scrapy`_ spiders.

It allows you to deploy your Scrapy projects and control their spiders using an
HTTP JSON API.

The documentation (including installation and usage) can be found at(官方文档在此):
https://scrapydart.readthedocs.io/zh/latest/

.. _Scrapy: https://github.com/dequinns/scrapydart
