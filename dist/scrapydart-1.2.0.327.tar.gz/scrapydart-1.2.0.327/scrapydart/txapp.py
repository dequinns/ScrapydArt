# this file is used to start scrapydart with twistd -y
from scrapydart import get_application
application = get_application()
